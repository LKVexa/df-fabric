"""Master-applied components."""
